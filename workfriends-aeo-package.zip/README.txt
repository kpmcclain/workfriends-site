WORKFRIENDS AEO PACKAGE

Deploy these files to the matching public paths:

/for-ai/index.html
/robots.txt
/sitemap.xml
/llms.txt
/answers/how-do-i-figure-out-tiktok-shop/index.html
/answers/should-my-brand-be-on-tiktok-shop/index.html
/answers/how-much-does-tiktok-shop-cost/index.html
/answers/how-to-choose-a-tiktok-shop-agency/index.html
/answers/what-is-tiktok-shop-market-intelligence/index.html
/answers/what-is-content-clipping/index.html
/answers/how-does-clipping-work-for-brands/index.html
/answers/owned-vs-rented-clipping-distribution/index.html

IMPORTANT:
- Keep the answer content visible in HTML. Structured data should match what users can see.
- Submit /sitemap.xml in Google Search Console and Bing Webmaster Tools.
- Keep OAI-SearchBot unblocked if you want content eligible to be surfaced and cited in ChatGPT search.
- The robots file currently also allows GPTBot. GPTBot is separate from OAI-SearchBot; allowing it is optional from a business-policy perspective.
- Add internal links from the public homepage or footer to /for-ai/ so crawlers and humans can discover it.
- Add future answer pages one question per URL when a recurring buyer question appears.
